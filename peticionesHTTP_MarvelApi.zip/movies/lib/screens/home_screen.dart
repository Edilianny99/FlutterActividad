import 'package:flutter/material.dart';
import 'package:movies/services/marvel_services.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<dynamic> characters = [];

 void loadCharacters() async {
  try {
    var response = await MarvelService().fetchCharacters();
    var data = response['data'] ?? {};  // Asegúrate de que 'data' existe
    var results = data['results'] as List;  // Aquí es donde necesitas acceder a la lista
    setState(() {
      characters = results;  // Almacena los personajes en la variable de estado
    });
  } catch (e) {
    print('Error al cargar personajes: $e');
  }
}


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage("assets/backgroundHome.jpg"),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Center(
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Welcome to EdiFlix',
                        style: TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            offset: Offset(2, 2),
                            blurRadius: 4,
                            color: Colors.black45,),
                        ],)),
                  SizedBox(height: 20),
                  Text('Discover, watch and enjoy',
                       style: 
                            TextStyle(
                              fontSize: 24,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                        shadows: [
                          Shadow(
                            offset: Offset(2, 2),
                            blurRadius: 4,
                            color: Colors.black45,),
                        ],
                             )
                      
                      ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: loadCharacters,
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple),
                    child: Text('Load Characters',
                        style: TextStyle(
                                  color: Colors.white,
                        )),
                  ),
                  Expanded(
                    
                    child: Container(
                         color: Colors.indigo[100],
                      child: ListView.builder(
                        itemCount: characters.length,
                        itemBuilder: (context, index) {
                          var character = characters[index];
                          return ListTile(
                            title: Text(character['name']),
                            subtitle: Text(character['description']),
                            leading: Image.network(character['thumbnail']['path'] + ".jpg"),
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
