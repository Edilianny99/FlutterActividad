import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';

class MarvelService {
  final String baseUrl = "https://gateway.marvel.com:443/v1/public";
  final String publicKey = '839c81b0ace143a4b8cc3d12af80d7e8';
  final String privateKey = '9b05775b37cb37f79ef8ae3050656b9a3161014a';

  Future<dynamic> fetchCharacters() async {
    var timestamp = DateTime.now().millisecondsSinceEpoch.toString();
    var hash = generateHash(timestamp, privateKey, publicKey);

    var response = await http.get(
      Uri.parse('$baseUrl/characters?ts=$timestamp&apikey=$publicKey&hash=$hash'),
    );

    if (response.statusCode == 200) {
      return json.decode(response.body);
    } else {
      throw Exception('Failed to load characters');
    }
  }

  String generateHash(String timestamp, String privateKey, String publicKey) {
    var bytes = utf8.encode(timestamp + privateKey + publicKey);
    var digest = md5.convert(bytes);
    return digest.toString();
  }
}