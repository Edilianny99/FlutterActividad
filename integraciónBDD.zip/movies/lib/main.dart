import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';



void main()  async {

 WidgetsFlutterBinding.ensureInitialized();
    await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}


Future<void> addMovie() async {
  CollectionReference movies = FirebaseFirestore.instance.collection('movies');
  print("Entraste");
  return movies
    .add({
      'title': 'Inception',
      'director': 'Christopher Nolan',
      'year': 2010
    })
    .then((value) => print("Movie Added"))
    .catchError((error) => print("Failed to add movie: $error"));
}


class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EdiFlix',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurpleAccent),
        useMaterial3: true,
      ),
      home: HomeScreen(),
    );
  }
}

